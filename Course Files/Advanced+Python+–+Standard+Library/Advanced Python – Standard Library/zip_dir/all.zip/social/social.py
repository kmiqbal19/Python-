print("Hey there")
